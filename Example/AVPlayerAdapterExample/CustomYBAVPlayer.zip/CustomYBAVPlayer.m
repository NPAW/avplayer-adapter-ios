//
//  CustomYBAVPlayer.m
//  AVPlayerAdapterExample
//
//  Created by Enrique Alfonso Burillo on 08/11/2018.
//  Copyright © 2018 NPAW. All rights reserved.
//

#import "CustomYBAVPlayer.h"

@implementation CustomYBAVPlayer

-(void) fireErrorWithMessage:(NSString *)msg code:(NSString *)code andMetadata:(NSString *)errorMetadata {
    if (![code isEqualToString:@"blach blach"]) {
        [super fireFatalErrorWithMessage:msg code:code andMetadata:errorMetadata];
    }
}

- (void) fireFatalErrorWithMessage:(NSString *)msg code:(NSString *)code andMetadata:(NSString *)errorMetadata {
    if (![code isEqualToString:@"blach blach"]) {
        [super fireFatalErrorWithMessage:msg code:code andMetadata:errorMetadata];
    }
}

@end
