//
//  CustomYBAVPlayer.h
//  AVPlayerAdapterExample
//
//  Created by Enrique Alfonso Burillo on 08/11/2018.
//  Copyright © 2018 NPAW. All rights reserved.
//

#import <YouboraAVPlayerAdapter/YouboraAVPlayerAdapter.h>

NS_ASSUME_NONNULL_BEGIN

@interface CustomYBAVPlayer : YBAVPlayerAdapter

@end

NS_ASSUME_NONNULL_END
